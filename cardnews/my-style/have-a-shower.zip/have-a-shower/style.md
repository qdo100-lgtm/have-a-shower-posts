# 스타일: have-a-shower

아트 디렉션: (deck.html 맨 위 주석에 적어 두면 여기에 나옴)

## 색
- --ink: #0B1440
- --paper: #F4F3F1
- --acc: #FFB8D9
- --cob: #1B3FEF

## 장 구성
- 1 커버
- 2 화제
- 3 크나이프
- 4 I-ne
- 5 바브
- 6 타이밍
- 7 요약·엔딩

## 폰트
- Gowun Batang
- Instrument Serif
- Pretendard

## 쓰는 법
template.html을 새 작업 폴더의 deck.html로 복사하고 문구·사진 경로만 바꾼다. 레이아웃·글자 크기·색은 건드리지 않는다.
장 수가 다르면 같은 종류의 장(section)을 복제하거나 지운다.
